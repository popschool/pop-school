import {Component} from 'angular2/core';

@Component({
    selector: 'my-app',
    template: `<h1>Hello world !</h1>`
})
export class AppComponent { }
